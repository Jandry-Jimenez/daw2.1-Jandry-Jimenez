<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="estilos.css">
    <title>Cerrar Sesión</title>
    <style>
        body {text-align: center}
        a {text-decoration: none; }
     </style>
</head>
<body>

<div class = "contenedor">
    
<header class="cabecera">  <!-- Cabecera -->
    <h1>SoundPlay<img src="img/logo.png" alt=40px" width="40px"></h1>
  </header>

    <h1>Sesión cerrada con éxito :)</h1>

    <p>Puedes volver a inciar sesión, otar vez</p>
    <a href = "SesionIniciar.php">Volver a iniciar Sesión</a>
</body>
</html>

