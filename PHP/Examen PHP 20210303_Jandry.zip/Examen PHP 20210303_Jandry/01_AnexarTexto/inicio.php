<?
?>

<html>
<head>
    <meta charset='UTF-8' />
    <link rel="shortcut icon" href="#">
</head>


<body>
<form action="inicio.php" method="post">

<h1>Escribe lo que quieras.</h1>
<input type='text' name='nombre' value='<?=$texto ?>' 
<br>

<input type="submit" value="Añadir"/>
<input type="submit" value="Reiniciar"/>
<br><br>

</form>
</body>

</html>